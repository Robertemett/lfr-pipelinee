#!/usr/bin/env python3
"""
Little Friends Rhymes – Full End-to-End YouTube Shorts Pipeline
==============================================================
Powered by **LTX 2.5** + automatic multi-clip stitching → full ~40s Shorts.

Usage:
  export LTX_API_KEY="your_key"

  # Full 40s multi-clip Short for Day 1
  python scripts/run_pipeline.py --day 1

  # Single short clip only (no stitching)
  python scripts/run_pipeline.py --day 1 --single-clip --duration 12

  # Batch
  python scripts/run_pipeline.py --from 1 --to 3

  # Preview prompts only
  python scripts/run_pipeline.py --day 1 --dry-run
"""

import argparse
import json
import os
import sys
from pathlib import Path

ROOT = Path(__file__).parent.parent.resolve()
sys.path.insert(0, str(ROOT))

from utils.config import CONTENT_JSON, OUTPUT_DIR
from utils.tts import generate_voiceover
from utils.thumbnail import create_thumbnail
from utils.ltx_client import (
    generate_day_video_with_ltx,
    build_segment_prompts,
)


def load_calendar() -> dict:
    with open(CONTENT_JSON, encoding="utf-8") as f:
        return json.load(f)


def main():
    parser = argparse.ArgumentParser(
        description="LFR YouTube Shorts Pipeline (LTX 2.5 + multi-clip stitch)"
    )
    parser.add_argument("--day", type=int, help="Single day (1-30)")
    parser.add_argument("--from", dest="from_day", type=int)
    parser.add_argument("--to", dest="to_day", type=int)
    parser.add_argument("--all", action="store_true")
    parser.add_argument("--no-ltx", action="store_true",
                        help="Only TTS + thumbnail")
    parser.add_argument("--force-tts", action="store_true")
    parser.add_argument("--model", default="ltx-2-5-fast",
                        choices=["ltx-2-5-fast", "ltx-2-5-pro"])
    parser.add_argument("--duration", type=int, default=10,
                        help="Per-clip duration when using --single-clip")
    parser.add_argument("--single-clip", action="store_true",
                        help="Generate only one LTX clip (no multi-clip stitch)")
    parser.add_argument("--dry-run", action="store_true",
                        help="Print segment prompts only, no API calls")
    args = parser.parse_args()

    calendar = load_calendar()
    days = calendar["days"]

    if args.day:
        selected = [d for d in days if d["day"] == args.day]
    elif args.from_day or args.to_day:
        start = args.from_day or 1
        end = args.to_day or 30
        selected = [d for d in days if start <= d["day"] <= end]
    elif args.all:
        selected = days
    else:
        parser.print_help()
        print("\n⚠️  Specify --day N  or  --from X --to Y  or  --all")
        sys.exit(1)

    if not selected:
        print("❌ No matching days")
        sys.exit(1)

    multi = not args.single_clip
    mode = "MULTI-CLIP (~40s)" if multi else f"SINGLE-CLIP ({args.duration}s)"

    print("\n🌈 Little Friends Rhymes × LTX 2.5 Pipeline")
    print(f"   Channel : {calendar['channel']['name']} {calendar['channel']['handle']}")
    print(f"   Days    : {[d['day'] for d in selected]}")
    print(f"   Mode    : {mode}")
    print(f"   Model   : {args.model}")
    print("-" * 55)

    if not args.no_ltx and not args.dry_run:
        if not (os.environ.get("LTX_API_KEY") or os.environ.get("LTXV_API_KEY")):
            print("❌ LTX_API_KEY not set.")
            print("   Get a key at https://ltx.io → Developer Console")
            print("   Then:  export LTX_API_KEY='sk-…'")
            sys.exit(1)

    results = []
    for d in selected:
        day_num = d["day"]
        print(f"\n▶ Day {day_num:02d} – {d['title']} ({d['combo']})")

        out_dir = OUTPUT_DIR / f"day_{day_num:02d}"
        out_dir.mkdir(parents=True, exist_ok=True)

        try:
            # 1. TTS
            vo = generate_voiceover(
                d.get("voiceover", d["title"]),
                day_num,
                force=args.force_tts,
            )
            print(f"   🎙️  Voiceover: {vo.name}")

            # 2. Thumbnail
            thumb = create_thumbnail(d)
            print(f"   🖼️  Thumbnail: {thumb.name}")

            # 3. Dry-run → show the 4 segment prompts
            if args.dry_run:
                segs = build_segment_prompts(d)
                print("\n   ── SEGMENT PROMPTS (dry-run) ──")
                for i, s in enumerate(segs, 1):
                    print(f"\n   [{i}] {s['label']} ({s['duration']}s)")
                    print(f"   {s['prompt'][:200]}…")
                print("\n   ──────────────────────────────\n")
                results.append({"day": day_num, "status": "dry_run"})
                continue

            if args.no_ltx:
                results.append({"day": day_num, "status": "tts_thumb_only"})
                continue

            # 4. LTX generation (+ automatic stitch)
            video_path = generate_day_video_with_ltx(
                day=d,
                out_dir=out_dir,
                model=args.model,
                clip_duration=args.duration,
                multi_clip=multi,
                voiceover_path=vo,
            )

            # 5. Metadata
            meta = {
                "day": day_num,
                "title": d["youtubeTitle"][:95],
                "description": (
                    f"{d['caption']}\n\n"
                    f"{d['description']}\n\n"
                    f"Learning: {d['learning']}\n"
                    f"Location: {d['location']}\n\n"
                    f"{' '.join(d.get('hashtags', []))}\n\n"
                    f"#LittleFriendsRhymes #NurseryRhymes #ToddlerLearning"
                ),
                "tags": d.get("hashtags", []) + [
                    "nursery rhymes", "kids songs", "toddler", "jj"
                ],
                "categoryId": "22",
                "privacyStatus": "private",
                "madeForKids": True,
                "ltx_model": args.model,
                "multi_clip": multi,
                "files": {
                    "video": str(video_path),
                    "thumbnail": str(thumb),
                    "voiceover": str(vo),
                },
            }
            meta_path = out_dir / "metadata.json"
            meta_path.write_text(
                json.dumps(meta, indent=2, ensure_ascii=False), encoding="utf-8"
            )
            print(f"   📋 Metadata: {meta_path.name}")

            results.append({
                "day": day_num,
                "success": True,
                "video": str(video_path),
                "thumbnail": str(thumb),
            })

        except Exception as e:
            print(f"   ❌ FAILED: {e}")
            results.append({"day": day_num, "status": "error", "error": str(e)})

    # Summary
    print("\n" + "=" * 55)
    ok = sum(1 for r in results if r.get("success"))
    print(f"✅ Completed: {ok}/{len(results)}")
    print(f"📂 Output   : {OUTPUT_DIR}")
    summary = OUTPUT_DIR / "batch_summary.json"
    summary.write_text(json.dumps(results, indent=2, default=str), encoding="utf-8")
    print(f"📊 Summary  : {summary}")
    print("=" * 55)


if __name__ == "__main__":
    main()
