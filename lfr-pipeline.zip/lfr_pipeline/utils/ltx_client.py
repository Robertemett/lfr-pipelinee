"""
LTX 2.5 API Client + Multi-Clip Stitching
=========================================
Generates real AI video clips using Lightricks LTX-2.5
and automatically stitches them into a full ~40s Short.
"""

import os
import time
import json
import subprocess
import tempfile
from pathlib import Path
from typing import Optional, List

import requests

# ── Config ────────────────────────────────────────────────────────────
LTX_API_BASE = "https://api.ltx.io/v2"
LTX_API_KEY = os.environ.get("LTX_API_KEY") or os.environ.get("LTXV_API_KEY")

DEFAULT_MODEL = "ltx-2-5-fast"
DEFAULT_RESOLUTION = "1080x1920"        # 9:16 portrait
DEFAULT_FPS = 24
DEFAULT_CLIP_DURATION = 10             # seconds per LTX clip
TARGET_TOTAL = 40                      # final Short length


class LTXClient:
    def __init__(self, api_key: str = None):
        self.api_key = api_key or LTX_API_KEY
        if not self.api_key:
            raise ValueError(
                "LTX_API_KEY not set.\n"
                "  export LTX_API_KEY='your_key_here'"
            )
        self.headers = {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json",
        }

    def text_to_video(
        self,
        prompt: str,
        model: str = DEFAULT_MODEL,
        duration: int | None = DEFAULT_CLIP_DURATION,
        resolution: str = DEFAULT_RESOLUTION,
        fps: int = DEFAULT_FPS,
        generate_audio: bool = True,
    ) -> dict:
        payload = {
            "prompt": prompt[:5000],
            "model": model,
            "duration": duration,
            "resolution": resolution,
            "fps": fps,
            "generate_audio": generate_audio,
        }
        resp = requests.post(
            f"{LTX_API_BASE}/text-to-video",
            headers=self.headers,
            json=payload,
            timeout=30,
        )
        resp.raise_for_status()
        return resp.json()

    def wait_for_job(
        self,
        job_id: str,
        endpoint: str = "text-to-video",
        poll_interval: float = 5.0,
        timeout: float = 600.0,
    ) -> dict:
        url = f"{LTX_API_BASE}/{endpoint}/{job_id}"
        start = time.time()
        while True:
            if time.time() - start > timeout:
                raise TimeoutError(f"LTX job {job_id} timed out after {timeout}s")
            resp = requests.get(url, headers=self.headers, timeout=30)
            resp.raise_for_status()
            data = resp.json()
            status = data.get("status")
            if status == "completed":
                return data
            if status == "failed":
                raise RuntimeError(f"LTX job failed: {data.get('error', data)}")
            print(f"      … LTX status: {status}")
            time.sleep(poll_interval)

    def download_video(self, video_url: str, out_path: Path) -> Path:
        out_path.parent.mkdir(parents=True, exist_ok=True)
        with requests.get(video_url, stream=True, timeout=120) as r:
            r.raise_for_status()
            with open(out_path, "wb") as f:
                for chunk in r.iter_content(chunk_size=8192):
                    f.write(chunk)
        return out_path


# ── Prompt builders ───────────────────────────────────────────────────
def _style_block() -> str:
    return (
        "Cute 3D cartoon style, soft pastel colors, big expressive eyes, "
        "chibi proportions, bright cheerful lighting, high quality animation, "
        "YouTube Shorts vertical 9:16 composition, kid-friendly, no text overlays."
    )


def _character_block(day: dict) -> str:
    companion = day.get("companion", "Puppy")
    emoji = day.get("emoji", "🐶")
    return (
        f"A happy toddler baby named JJ with big cheeks and soft hair, "
        f"dancing and playing together with a cute {companion.lower()} {emoji}."
    )


def build_segment_prompts(day: dict) -> List[dict]:
    """
    Split one day into 4 logical segments that can each become an LTX clip.
    Returns list of {label, duration, prompt}.
    """
    style = _style_block()
    character = _character_block(day)
    location = day.get("location", "a bright room")
    learning = day.get("learning", "fun learning")
    title = day.get("title", "")

    segments = [
        {
            "label": "hook",
            "duration": 8,
            "prompt": (
                f"{style} {character} "
                f"Scene opens in {location}. "
                f"Exciting opening: {day.get('hook', 'JJ and friend appear happily')}. "
                f"Big energy, smile to camera, start of the dance. "
                f"Learning theme: {learning}."
            ),
        },
        {
            "label": "main_a",
            "duration": 12,
            "prompt": (
                f"{style} {character} "
                f"Continuing the same scene in {location}. "
                f"Main dance action: {day.get('main', title)}. "
                f"JJ and the companion are actively dancing, pointing, counting or naming colors/animals. "
                f"Keep the same characters, same outfits, same lighting."
            ),
        },
        {
            "label": "main_b",
            "duration": 12,
            "prompt": (
                f"{style} {character} "
                f"Same location {location}, same characters. "
                f"They continue the activity with more energy and interaction. "
                f"Focus on the teaching moment: {learning}. "
                f"Playful movement, eye contact with camera, joyful expressions."
            ),
        },
        {
            "label": "finale",
            "duration": 10,
            "prompt": (
                f"{style} {character} "
                f"Finale in {location}. "
                f"{day.get('finale', 'They finish with a big smile and heart hands')}. "
                f"Both characters wave goodbye, happy ending, soft camera pull-back."
            ),
        },
    ]
    return segments


def stitch_clips(
    clip_paths: List[Path],
    out_path: Path,
    crossfade: float = 0.4,
) -> Path:
    """
    Stitch multiple MP4s with short crossfades using FFmpeg xfade.
    Falls back to simple concat if only one clip or xfade fails.
    """
    out_path.parent.mkdir(parents=True, exist_ok=True)

    if len(clip_paths) == 1:
        # just copy
        subprocess.run(
            ["ffmpeg", "-y", "-i", str(clip_paths[0]), "-c", "copy", str(out_path)],
            check=True, capture_output=True,
        )
        return out_path

    # Build complex filter for successive xfades
    # First get durations
    durations = []
    for p in clip_paths:
        r = subprocess.run(
            [
                "ffprobe", "-v", "error",
                "-show_entries", "format=duration",
                "-of", "default=noprint_wrappers=1:nokey=1",
                str(p),
            ],
            capture_output=True, text=True, check=True,
        )
        durations.append(float(r.stdout.strip()))

    # xfade chain
    inputs = []
    for p in clip_paths:
        inputs.extend(["-i", str(p)])

    filter_parts = []
    # Start with first two
    offset = durations[0] - crossfade
    filter_parts.append(
        f"[0:v][1:v]xfade=transition=fade:duration={crossfade}:offset={offset}[v01];"
        f"[0:a][1:a]acrossfade=d={crossfade}[a01]"
    )
    last_v, last_a = "v01", "a01"
    running_dur = durations[0] + durations[1] - crossfade

    for i in range(2, len(clip_paths)):
        offset = running_dur - crossfade
        new_v = f"v0{i}"
        new_a = f"a0{i}"
        filter_parts.append(
            f"[{last_v}][{i}:v]xfade=transition=fade:duration={crossfade}:offset={offset}[{new_v}];"
            f"[{last_a}][{i}:a]acrossfade=d={crossfade}[{new_a}]"
        )
        last_v, last_a = new_v, new_a
        running_dur += durations[i] - crossfade

    filter_complex = "".join(filter_parts)

    cmd = [
        "ffmpeg", "-y",
        *inputs,
        "-filter_complex", filter_complex,
        "-map", f"[{last_v}]",
        "-map", f"[{last_a}]",
        "-c:v", "libx264", "-preset", "medium", "-crf", "20",
        "-c:a", "aac", "-b:a", "192k",
        "-movflags", "+faststart",
        "-pix_fmt", "yuv420p",
        str(out_path),
    ]

    result = subprocess.run(cmd, capture_output=True, text=True)
    if result.returncode != 0:
        # Fallback: simple concat demuxer
        print("   ⚠️  xfade failed, falling back to hard concat")
        with tempfile.NamedTemporaryFile("w", suffix=".txt", delete=False) as f:
            for p in clip_paths:
                f.write(f"file '{p.resolve()}'\n")
            list_path = f.name
        try:
            subprocess.run(
                [
                    "ffmpeg", "-y", "-f", "concat", "-safe", "0",
                    "-i", list_path, "-c", "copy", str(out_path),
                ],
                check=True, capture_output=True,
            )
        finally:
            os.unlink(list_path)

    return out_path


def generate_day_video_with_ltx(
    day: dict,
    out_dir: Path,
    model: str = DEFAULT_MODEL,
    clip_duration: int = DEFAULT_CLIP_DURATION,
    multi_clip: bool = True,
    voiceover_path: Optional[Path] = None,
) -> Path:
    """
    Generate one full Short.
    If multi_clip=True → creates 4 segments, stitches them → ~40s video.
    """
    client = LTXClient()
    out_dir.mkdir(parents=True, exist_ok=True)

    if not multi_clip:
        # Single clip mode (legacy)
        prompt = (
            f"{_style_block()} {_character_block(day)} "
            f"Scene: {day.get('location')}. {day.get('hook')} {day.get('main')} {day.get('finale')}"
        )
        print(f"   🎬 Single LTX prompt ({len(prompt)} chars)")
        job = client.text_to_video(prompt=prompt, model=model, duration=clip_duration)
        result = client.wait_for_job(job["id"])
        final = out_dir / "video_ltx.mp4"
        client.download_video(result["result"]["video_url"], final)
        return final

    # ── Multi-clip path ───────────────────────────────────────────────
    segments = build_segment_prompts(day)
    clip_paths: List[Path] = []

    print(f"   🎬 Multi-clip mode → {len(segments)} segments")

    for i, seg in enumerate(segments, 1):
        print(f"   [{i}/{len(segments)}] Generating “{seg['label']}” ({seg['duration']}s)…")
        job = client.text_to_video(
            prompt=seg["prompt"],
            model=model,
            duration=seg["duration"],
            generate_audio=True,
        )
        print(f"      job id: {job['id']}")
        result = client.wait_for_job(job["id"])
        clip_file = out_dir / f"clip_{i:02d}_{seg['label']}.mp4"
        client.download_video(result["result"]["video_url"], clip_file)
        clip_paths.append(clip_file)
        print(f"      ✅ {clip_file.name}")

    # Stitch
    final = out_dir / "video_ltx.mp4"
    print(f"   🔗 Stitching {len(clip_paths)} clips with crossfades…")
    stitch_clips(clip_paths, final, crossfade=0.35)
    print(f"   ✅ Final video → {final.name}")

    # Optional: replace / mix with full TTS voiceover
    if voiceover_path and voiceover_path.exists():
        mixed = out_dir / "video_ltx_vo.mp4"
        print("   🎙️  Mixing full TTS voiceover on top…")
        subprocess.run(
            [
                "ffmpeg", "-y",
                "-i", str(final),
                "-i", str(voiceover_path),
                "-filter_complex",
                "[0:a]volume=0.35[bg];[1:a]volume=1.0[vo];"
                "[bg][vo]amix=inputs=2:duration=first:dropout_transition=2[a]",
                "-map", "0:v", "-map", "[a]",
                "-c:v", "copy",
                "-c:a", "aac", "-b:a", "192k",
                "-shortest",
                str(mixed),
            ],
            check=True, capture_output=True,
        )
        # Prefer the mixed version
        mixed.replace(final)
        print(f"   ✅ Voiceover mixed → {final.name}")

    return final
