"""
Text-to-Speech using edge-tts (free, high quality, child-friendly voices)
"""
import asyncio
from pathlib import Path
from edge_tts import Communicate
from .config import TTS_VOICE, TTS_RATE, TTS_PITCH, VOICES_DIR


async def _generate(text: str, out_path: Path, voice: str = TTS_VOICE):
    communicate = Communicate(text, voice, rate=TTS_RATE, pitch=TTS_PITCH)
    await communicate.save(str(out_path))


def generate_voiceover(text: str, day: int, force: bool = False) -> Path:
    """Generate or return cached voiceover WAV/MP3 for a given day."""
    VOICES_DIR.mkdir(parents=True, exist_ok=True)
    out = VOICES_DIR / f"day_{day:02d}_vo.mp3"

    if out.exists() and not force:
        return out

    # Clean text for TTS (remove stage directions if any)
    clean = text.strip()
    if not clean:
        clean = "Yay! Let's learn together!"

    asyncio.run(_generate(clean, out))
    return out


def generate_all_voiceovers(days: list, force: bool = False):
    """Batch generate voiceovers for a list of day dicts."""
    results = []
    for d in days:
        path = generate_voiceover(d.get("voiceover", d["title"]), d["day"], force=force)
        results.append({"day": d["day"], "path": str(path)})
        print(f"  ✅ Day {d['day']:02d} voiceover → {path.name}")
    return results
