"""
Thumbnail generator – 1080×1920 YouTube Shorts style
Matches the official LFR Thumbnail Studio from the React app.
"""
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont
from .config import WIDTH, HEIGHT, OUTPUT_DIR, BRAND


def _get_font(size: int, bold: bool = True):
    """Try common system fonts, fall back to default."""
    candidates = [
        "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf",
        "/usr/share/fonts/truetype/liberation/LiberationSans-Bold.ttf",
        "/usr/share/fonts/truetype/freefont/FreeSansBold.ttf",
        "arial.ttf",
    ]
    for c in candidates:
        try:
            return ImageFont.truetype(c, size)
        except Exception:
            continue
    return ImageFont.load_default()


def create_thumbnail(day_data: dict, style: str = "Bubbly Pop") -> Path:
    """
    Create a high-CTR 9:16 thumbnail for the given day.
    Returns path to the saved PNG.
    """
    day = day_data["day"]
    bg_color = day_data.get("bg", "#E8F1FF")
    companion = day_data.get("companion", "Puppy")
    emoji = day_data.get("emoji", "🐶")
    title = day_data.get("title", f"Day {day}")
    learning = day_data.get("learning", "Learning Fun")
    learn_icon = day_data.get("learnIcon", "✨")
    location = day_data.get("location", "")
    location_emoji = day_data.get("locationEmoji", "")

    # ── Canvas ─────────────────────────────────────────────────────────
    img = Image.new("RGB", (WIDTH, HEIGHT), bg_color)
    draw = ImageDraw.Draw(img)

    # Soft gradient overlay (approximate with rectangles)
    for i in range(HEIGHT // 4):
        alpha = int(40 * (1 - i / (HEIGHT // 4)))
        color = (255, 255, 255, alpha)
        # We stay RGB for simplicity

    # Decorative circles
    for cx, cy, r, col in [
        (int(WIDTH * 0.15), int(HEIGHT * 0.18), int(WIDTH * 0.22), (255, 255, 255, 40)),
        (int(WIDTH * 0.85), int(HEIGHT * 0.25), int(WIDTH * 0.18), (255, 255, 255, 40)),
        (int(WIDTH * 0.50), int(HEIGHT * 0.88), int(WIDTH * 0.35), (255, 255, 255, 30)),
    ]:
        # Draw with low opacity simulation
        overlay = Image.new("RGBA", (WIDTH, HEIGHT), (0, 0, 0, 0))
        od = ImageDraw.Draw(overlay)
        od.ellipse([cx - r, cy - r, cx + r, cy + r], fill=(255, 255, 255, 45))
        img = Image.alpha_composite(img.convert("RGBA"), overlay).convert("RGB")
        draw = ImageDraw.Draw(img)

    # Top channel badge
    badge_w, badge_h = int(WIDTH * 0.62), int(HEIGHT * 0.042)
    badge_x = (WIDTH - badge_w) // 2
    badge_y = int(HEIGHT * 0.045)
    draw.rounded_rectangle(
        [badge_x, badge_y, badge_x + badge_w, badge_y + badge_h],
        radius=badge_h // 2,
        fill="#1A1520",
    )
    font_small = _get_font(28)
    draw.text(
        (WIDTH // 2, badge_y + badge_h // 2),
        f"▶ {BRAND['name']}",
        font=font_small,
        fill="white",
        anchor="mm",
    )

    # Main character card
    card_w, card_h = int(WIDTH * 0.78), int(HEIGHT * 0.38)
    card_x = int(WIDTH * 0.11)
    card_y = int(HEIGHT * 0.16)
    draw.rounded_rectangle(
        [card_x, card_y, card_x + card_w, card_y + card_h],
        radius=int(WIDTH * 0.06),
        fill=(255, 255, 255),
        outline=(240, 240, 240),
        width=4,
    )

    # JJ + companion emojis (large)
    font_emoji = _get_font(180)
    # JJ
    draw.text(
        (int(WIDTH * 0.38), card_y + int(card_h * 0.55)),
        "👶",
        font=font_emoji,
        anchor="mm",
    )
    # Companion
    draw.text(
        (int(WIDTH * 0.62), card_y + int(card_h * 0.55)),
        emoji,
        font=font_emoji,
        anchor="mm",
    )
    # Plus
    font_plus = _get_font(70)
    draw.text(
        (WIDTH // 2, card_y + int(card_h * 0.48)),
        "+",
        font=font_plus,
        fill="#2A1F33",
        anchor="mm",
    )

    # Labels under emojis
    font_label = _get_font(32)
    draw.text(
        (int(WIDTH * 0.38), card_y + int(card_h * 0.82)),
        "JJ",
        font=font_label,
        fill="#3A2E44",
        anchor="mm",
    )
    draw.text(
        (int(WIDTH * 0.62), card_y + int(card_h * 0.82)),
        companion,
        font=font_label,
        fill="#3A2E44",
        anchor="mm",
    )

    # Learning badge
    accent = {"Puppy": "#5B8DEF", "Teddy": "#E88A4A", "Bunny": "#2FB67A"}.get(
        companion, "#5B8DEF"
    )
    learn_w, learn_h = int(WIDTH * 0.66), int(HEIGHT * 0.055)
    learn_x = (WIDTH - learn_w) // 2
    learn_y = card_y + card_h + int(HEIGHT * 0.018)
    draw.rounded_rectangle(
        [learn_x, learn_y, learn_x + learn_w, learn_y + learn_h],
        radius=learn_h // 2,
        fill=accent,
    )
    font_learn = _get_font(26)
    learn_text = f"{learn_icon} {learning}".upper()[:28]
    draw.text(
        (WIDTH // 2, learn_y + learn_h // 2),
        learn_text,
        font=font_learn,
        fill="white",
        anchor="mm",
    )

    # Title (max 2 lines)
    font_title = _get_font(72)
    words = title.split()
    lines = []
    current = ""
    for w in words:
        test = (current + " " + w).strip()
        if len(test) > 16 and current:
            lines.append(current)
            current = w
        else:
            current = test
    if current:
        lines.append(current)
    lines = lines[:2]

    title_y = int(HEIGHT * 0.66)
    for i, line in enumerate(lines):
        y = title_y + i * int(HEIGHT * 0.065)
        # stroke
        for dx, dy in [(-3, 0), (3, 0), (0, -3), (0, 3), (-2, -2), (2, 2)]:
            draw.text((WIDTH // 2 + dx, y + dy), line, font=font_title, fill="white", anchor="mm")
        draw.text((WIDTH // 2, y), line, font=font_title, fill="#1E1528", anchor="mm")

    # Bottom day badge
    day_w, day_h = int(WIDTH * 0.28), int(HEIGHT * 0.045)
    day_x, day_y = int(WIDTH * 0.08), int(HEIGHT * 0.905)
    draw.rounded_rectangle(
        [day_x, day_y, day_x + day_w, day_y + day_h],
        radius=day_h // 2,
        fill="#FFE88F",
    )
    font_day = _get_font(26)
    draw.text(
        (day_x + day_w // 2, day_y + day_h // 2),
        f"DAY {day} • 40s",
        font=font_day,
        fill="#6B4E00",
        anchor="mm",
    )

    # Location badge
    loc_w = int(WIDTH * 0.34)
    loc_x = int(WIDTH * 0.58)
    draw.rounded_rectangle(
        [loc_x, day_y, loc_x + loc_w, day_y + day_h],
        radius=day_h // 2,
        fill="white",
    )
    draw.text(
        (loc_x + loc_w // 2, day_y + day_h // 2),
        f"{location_emoji} {location}"[:18],
        font=_get_font(22),
        fill="#3A2E44",
        anchor="mm",
    )

    # Save
    out_dir = OUTPUT_DIR / f"day_{day:02d}"
    out_dir.mkdir(parents=True, exist_ok=True)
    out_path = out_dir / "thumbnail.png"
    img.save(out_path, "PNG", quality=95)
    return out_path
