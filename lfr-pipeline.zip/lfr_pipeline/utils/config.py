"""
Little Friends Rhymes - Pipeline Configuration
"""
from pathlib import Path

# ── Paths ──────────────────────────────────────────────────────────────
ROOT = Path(__file__).parent.parent.resolve()
DATA_DIR = ROOT / "data"
ASSETS_DIR = ROOT / "assets"
MUSIC_DIR = ASSETS_DIR / "music"
VOICES_DIR = ASSETS_DIR / "voices"
IMAGES_DIR = ASSETS_DIR / "images"
OUTPUT_DIR = ROOT / "output"

CONTENT_JSON = DATA_DIR / "content_calendar.json"

# ── Video Specs (YouTube Shorts) ───────────────────────────────────────
WIDTH = 1080
HEIGHT = 1920
FPS = 30
DURATION_TARGET = 40          # seconds
VIDEO_BITRATE = "8M"
AUDIO_BITRATE = "192k"

# ── TTS Settings ───────────────────────────────────────────────────────
# Use a child-friendly voice. edge-tts voices:
# en-US-AnaNeural (female child-like), en-US-JennyNeural, etc.
TTS_VOICE = "en-US-AnaNeural"
TTS_RATE = "+8%"              # slightly faster for energy
TTS_PITCH = "+5Hz"

# ── Branding ───────────────────────────────────────────────────────────
BRAND = {
    "name": "Little Friends Rhymes",
    "handle": "@littlefriendsryhmes",
    "primary": "#FF2D55",
    "accent": "#FFE88F",
    "text_dark": "#2A1F33",
    "font_main": "DejaVu-Sans-Bold",   # fallback; system fonts
}

# ── Music (put royalty-free tracks in assets/music/) ───────────────────
# Pipeline will look for these names; if missing it generates silence + tone
DEFAULT_MUSIC = {
    "upbeat": "upbeat_kids.mp3",
    "calm": "lullaby.mp3",
    "party": "party_pop.mp3",
}

# ── Safety ─────────────────────────────────────────────────────────────
MAX_PARALLEL = 2              # concurrent renders
PRIVATE_BY_DEFAULT = True     # never auto-public
