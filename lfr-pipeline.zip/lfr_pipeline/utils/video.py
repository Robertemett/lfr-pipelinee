"""
Video assembler – creates 40-second 9:16 Shorts using FFmpeg.
Uses colored backgrounds + text overlays + Ken Burns + voiceover + music.
"""
import json
import subprocess
import tempfile
from pathlib import Path
from .config import (
    WIDTH, HEIGHT, FPS, DURATION_TARGET, VIDEO_BITRATE, AUDIO_BITRATE,
    OUTPUT_DIR, MUSIC_DIR, VOICES_DIR, BRAND
)


def _run(cmd: list, check: bool = True):
    """Run a command and return CompletedProcess."""
    result = subprocess.run(
        cmd,
        capture_output=True,
        text=True,
    )
    if check and result.returncode != 0:
        raise RuntimeError(f"Command failed:\n{' '.join(cmd)}\n{result.stderr}")
    return result


def _create_background_image(bg_color: str, day: int, tmp_dir: Path) -> Path:
    """Create a solid color background image for the video."""
    from PIL import Image, ImageDraw, ImageFont

    img = Image.new("RGB", (WIDTH, HEIGHT), bg_color)
    draw = ImageDraw.Draw(img)

    # Soft decorative circles
    for cx, cy, r in [
        (int(WIDTH * 0.2), int(HEIGHT * 0.15), 280),
        (int(WIDTH * 0.8), int(HEIGHT * 0.3), 220),
        (int(WIDTH * 0.5), int(HEIGHT * 0.85), 350),
    ]:
        overlay = Image.new("RGBA", (WIDTH, HEIGHT), (0, 0, 0, 0))
        od = ImageDraw.Draw(overlay)
        od.ellipse([cx - r, cy - r, cx + r, cy + r], fill=(255, 255, 255, 35))
        img = Image.alpha_composite(img.convert("RGBA"), overlay).convert("RGB")
        draw = ImageDraw.Draw(img)

    path = tmp_dir / f"bg_day{day:02d}.png"
    img.save(path)
    return path


def _create_text_overlay(
    title: str,
    learning: str,
    emoji: str,
    companion: str,
    day: int,
    tmp_dir: Path,
) -> Path:
    """Create a transparent PNG with title + learning badge for overlay."""
    from PIL import Image, ImageDraw, ImageFont

    img = Image.new("RGBA", (WIDTH, HEIGHT), (0, 0, 0, 0))
    draw = ImageDraw.Draw(img)

    def font(size):
        for f in [
            "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf",
            "/usr/share/fonts/truetype/liberation/LiberationSans-Bold.ttf",
        ]:
            try:
                return ImageFont.truetype(f, size)
            except Exception:
                pass
        return ImageFont.load_default()

    # Top channel badge
    draw.rounded_rectangle(
        [180, 60, 900, 130],
        radius=35,
        fill=(26, 21, 32, 230),
    )
    draw.text((540, 95), f"▶ {BRAND['name']}", font=font(28), fill="white", anchor="mm")

    # Big emoji pair
    draw.text((380, 480), "👶", font=font(160), anchor="mm")
    draw.text((700, 480), emoji, font=font(160), anchor="mm")
    draw.text((540, 480), "+", font=font(70), fill="#2A1F33", anchor="mm")

    # Learning badge
    accent = {"Puppy": (91, 141, 239), "Teddy": (232, 138, 74), "Bunny": (47, 182, 122)}.get(
        companion, (91, 141, 239)
    )
    draw.rounded_rectangle(
        [160, 720, 920, 810],
        radius=45,
        fill=accent + (240,),
    )
    draw.text((540, 765), f"{learning}"[:32], font=font(30), fill="white", anchor="mm")

    # Title
    words = title.split()
    lines, cur = [], ""
    for w in words:
        test = (cur + " " + w).strip()
        if len(test) > 14 and cur:
            lines.append(cur)
            cur = w
        else:
            cur = test
    if cur:
        lines.append(cur)
    lines = lines[:2]

    y = 980
    for line in lines:
        # White stroke
        for dx, dy in [(-4, 0), (4, 0), (0, -4), (0, 4)]:
            draw.text((540 + dx, y + dy), line, font=font(64), fill="white", anchor="mm")
        draw.text((540, y), line, font=font(64), fill="#1E1528", anchor="mm")
        y += 90

    # Day badge
    draw.rounded_rectangle(
        [80, 1750, 380, 1830],
        radius=40,
        fill=(255, 232, 143, 240),
    )
    draw.text((230, 1790), f"DAY {day} • 40s", font=font(28), fill="#6B4E00", anchor="mm")

    path = tmp_dir / f"overlay_day{day:02d}.png"
    img.save(path)
    return path


def build_video(day_data: dict, music_path: Path | None = None) -> dict:
    """
    Full pipeline for one day:
    1. Background image
    2. Text overlay
    3. Voiceover (already generated)
    4. FFmpeg assemble → 40s 9:16 MP4
    5. Captions SRT
    6. Metadata JSON
    """
    day = day_data["day"]
    out_dir = OUTPUT_DIR / f"day_{day:02d}"
    out_dir.mkdir(parents=True, exist_ok=True)

    video_out = out_dir / "video.mp4"
    srt_out = out_dir / "captions.srt"
    meta_out = out_dir / "metadata.json"
    log_out = out_dir / "render-log.txt"

    with tempfile.TemporaryDirectory() as tmp:
        tmp_dir = Path(tmp)

        # 1. Background
        bg = _create_background_image(day_data.get("bg", "#E8F1FF"), day, tmp_dir)

        # 2. Overlay
        overlay = _create_text_overlay(
            day_data["title"],
            day_data.get("learning", ""),
            day_data.get("emoji", "🐶"),
            day_data.get("companion", "Puppy"),
            day,
            tmp_dir,
        )

        # 3. Voiceover
        vo_path = VOICES_DIR / f"day_{day:02d}_vo.mp3"
        if not vo_path.exists():
            from .tts import generate_voiceover
            vo_path = generate_voiceover(day_data.get("voiceover", day_data["title"]), day)

        # 4. Build FFmpeg command
        # Ken Burns effect on background + overlay + audio mix
        filter_complex = (
            f"[0:v]scale={WIDTH}:{HEIGHT},"
            f"zoompan=z='min(zoom+0.0008,1.12)':x='iw/2-(iw/zoom/2)':y='ih/2-(ih/zoom/2)':"
            f"d={DURATION_TARGET * FPS}:s={WIDTH}x{HEIGHT}:fps={FPS}[bg];"
            f"[1:v]scale={WIDTH}:{HEIGHT}[ov];"
            f"[bg][ov]overlay=0:0:format=auto,format=yuv420p[v]"
        )

        cmd = [
            "ffmpeg", "-y",
            "-loop", "1", "-i", str(bg),
            "-i", str(overlay),
            "-i", str(vo_path),
        ]

        # Optional background music (ducked)
        if music_path and music_path.exists():
            cmd.extend(["-i", str(music_path)])
            filter_complex += (
                f";[2:a]volume=1.0[vo];"
                f"[3:a]volume=0.18,afade=t=in:st=0:d=1,afade=t=out:st={DURATION_TARGET-2}:d=2[music];"
                f"[vo][music]amix=inputs=2:duration=first:dropout_transition=2[a]"
            )
            map_audio = ["-map", "[a]"]
        else:
            filter_complex += ";[2:a]volume=1.0[a]"
            map_audio = ["-map", "[a]"]

        cmd.extend([
            "-filter_complex", filter_complex,
            "-map", "[v]",
            *map_audio,
            "-c:v", "libx264", "-preset", "medium", "-crf", "20",
            "-b:v", VIDEO_BITRATE,
            "-c:a", "aac", "-b:a", AUDIO_BITRATE,
            "-t", str(DURATION_TARGET),
            "-movflags", "+faststart",
            "-pix_fmt", "yuv420p",
            str(video_out),
        ])

        result = _run(cmd, check=False)
        log_out.write_text(result.stdout + "\n" + result.stderr)

        if result.returncode != 0 or not video_out.exists():
            raise RuntimeError(f"FFmpeg failed for day {day}. See {log_out}")

        # 5. Simple SRT from voiceover text
        vo_text = day_data.get("voiceover", day_data["title"])
        # Split into roughly equal chunks
        words = vo_text.split()
        chunk_size = max(4, len(words) // 4)
        chunks = [" ".join(words[i:i + chunk_size]) for i in range(0, len(words), chunk_size)]
        srt_lines = []
        seg = DURATION_TARGET / max(len(chunks), 1)
        for i, chunk in enumerate(chunks):
            start = i * seg
            end = (i + 1) * seg
            srt_lines.append(f"{i+1}")
            srt_lines.append(
                f"{_ts(start)} --> {_ts(end)}"
            )
            srt_lines.append(chunk)
            srt_lines.append("")
        srt_out.write_text("\n".join(srt_lines), encoding="utf-8")

        # 6. Metadata
        meta = {
            "day": day,
            "title": day_data["youtubeTitle"][:95],
            "description": (
                f"{day_data['caption']}\n\n"
                f"{day_data['description']}\n\n"
                f"Learning: {day_data['learning']}\n"
                f"Location: {day_data['location']}\n\n"
                f"{' '.join(day_data.get('hashtags', []))}\n\n"
                f"#{BRAND['handle']} #NurseryRhymes #ToddlerLearning"
            ),
            "tags": day_data.get("hashtags", []) + ["nursery rhymes", "kids songs", "toddler"],
            "categoryId": "22",          # People & Blogs / Education-ish
            "privacyStatus": "private",
            "madeForKids": True,
            "duration_target": DURATION_TARGET,
            "companion": day_data.get("companion"),
            "files": {
                "video": str(video_out),
                "thumbnail": str(out_dir / "thumbnail.png"),
                "captions": str(srt_out),
            },
        }
        meta_out.write_text(json.dumps(meta, indent=2, ensure_ascii=False), encoding="utf-8")

    return {
        "day": day,
        "video": str(video_out),
        "srt": str(srt_out),
        "metadata": str(meta_out),
        "success": True,
    }


def _ts(seconds: float) -> str:
    """Seconds → SRT timestamp."""
    h = int(seconds // 3600)
    m = int((seconds % 3600) // 60)
    s = int(seconds % 60)
    ms = int((seconds % 1) * 1000)
    return f"{h:02d}:{m:02d}:{s:02d},{ms:03d}"
